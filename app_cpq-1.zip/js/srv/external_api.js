const https = require('https');
const xsenv = require("@sap/xsenv");
const axios = require('axios');
const appConfig = require('../config/app');

let externalApi = {};

externalApi.callApi = async(request) => {
	return new Promise((resolve, reject) => {
		const httpsAgent = new https.Agent({
			rejectUnauthorized: false,
		});
		let config =  {
			httpsAgent,
			headers: {
				Accept: 'application/json',
				'Content-Type': 'application/json'
			}
		};

		if (request.methodType == 'GET') {
			axios.get(request.url, config)
				.then((response) => {
					//console.log("Response here", response.data)
					return resolve(response.data);
				})
				.catch((error) => {
					console.log(error);
					reject(error);
				})
		} else if (methodType == 'PUT') {
			axios.put(actualUrl, request.query, config)
				.then(function (response) {
					// handle success
					console.log(response);
					resolve(response);
				})
				.catch(function (error) {
					// handle error
					console.log(error);
					reject(error);
				})
		} else if (methodType == 'POST') {
			console.log("config 11", JSON.stringify(config))
			axios.post(actualUrl, JSON.stringify(request.query), config)
				.then(function (response) {
					// handle success
					console.log("Success on API call", response);
					resolve(response);
				})
				.catch(function (error) {
					// handle error
					console.log("Error on API call", error);
					reject(error);
				})
		} else if (methodType == 'DELETE') {
			axios.delete(actualUrl, config)
				.then(function (response) {
					// handle success
					console.log(response);
					resolve(response);
				})
				.catch(function (error) {
					// handle error
					console.log(error);
					reject(error);
				})
		}
	})
};

module.exports = externalApi;