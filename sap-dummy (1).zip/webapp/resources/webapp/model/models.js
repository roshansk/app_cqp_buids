sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"sap/ui/model/odata/v2/ODataModel",
], function (JSONModel, Device ,ODataModel) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		
		
		initOData : function() {
			
			this.oDataModel = new ODataModel("/service.xsodata",{
				defaultBindingMode:sap.ui.model.BindingMode.TwoWay,                                         
				defaultUpdateMethod:sap.ui.model.odata.UpdateMethod.Put,
				disableHeadRequestForToken:true,
				json:true, 
				useBatch:false,
			});
			
			console.log("model.js",this.oDataModel);
		}

	};
});