sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/base/util/uid"
], function (UIComponent, JSONModel, uid) {
	"use strict";

	return UIComponent.extend("UI5_webapp.webapp.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			
			//User Template Model
			
			this.data = {
				
				userTemplate : {
					u_id:"",
					u_name:"",
					u_email:"",
					u_role:"",
					u_password:""
				},
				
				users : [
						
				],
				
				
			};
			
			this.oModel = new JSONModel(this.data);
			this.setModel(this.oModel,"userTemplateModel");
		
			
			// enable routing
			this.getRouter().initialize();

			// set the device model
			//this.setModel(models.createDeviceModel(), "device");
		},
		
		//Add blank user to JSON data
		addBlankUser : function ( user ) {
			this.data.users.push({
				u_id: user ? user.u_id : "",
				u_name:user ? user.u_name : "",
				u_email:user ? user.u_email : "",
				u_role:user ? user.u_role : "",
				u_password: user ? user.u_password : ""
			});
			this.oModel.refresh();

		},
		
		resetUsers : function(){
			this.data.users = [];
			this.oModel.refresh();
		}
	});
});