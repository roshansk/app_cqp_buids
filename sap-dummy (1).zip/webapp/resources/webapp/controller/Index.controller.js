/* global Papa:true */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	'sap/m/ColumnListItem',
	'sap/m/Input',
	'sap/m/Text',
	"sap/m/ObjectIdentifier",
	"sap/m/MessageToast",
	"../libs/papaparse"
], function (Controller, Fragment, JSONModel, ODataModel, ColumnListItem, Input, Text, ObjectIdentifier, MessageToast, Papajs) {
	"use strict";

	return Controller.extend("UI5_webapp.webapp.controller.Index", {
		
		onInit: function () {
			// Odata service
			
			var oDataJSON = new JSONModel({"results":[]});
			this.getView().setModel(oDataJSON,"userJSONModel");
			
			this.oDataModel = new ODataModel("/service.xsodata",{
				defaultBindingMode:sap.ui.model.BindingMode.TwoWay,                                         
				defaultUpdateMethod:sap.ui.model.odata.UpdateMethod.Put,
				disableHeadRequestForToken:true,
				json:true, 
				useBatch:false,
			});

			this.oDataModel.read("/userModel", {
			success : function(odata,res){
				var ids = [];
				odata.results.map( user => {
					ids.push(user.u_id);
				} )
				oDataJSON.setData({"results":odata.results,"ids":ids});
			},
			error : function (err) {
				console.log(err);
			}
				
			});
			this.getView().setModel(this.oDataModel,"userODataModel");
			
			var oTable = this.getView().byId("userSmartTable");
			var oSmartFilter = this.getView().byId("smartFilterBar");
			oTable.setModel(this.oDataModel);
			oSmartFilter.setModel(this.oDataModel);
			oTable.setEntitySet("userModel");
			oTable.setInitiallyVisibleFields("u_id,u_name,u_email,u_role");
			
			
			//Upload Table logic
			
			this.userTemplateModel = this.getView().getModel("userTemplateModel");
			this.editableUserTemplate =  new ColumnListItem({
				cells: [
					new Input({
						value: "{userTemplateModel>u_id}",
					}), 
					new Input({
						value: "{userTemplateModel>u_name}"
					}), 
					new Input({
						value: "{userTemplateModel>u_email}"
					}), 
					new Input({
						value: "{userTemplateModel>u_role}"
					}), 
					new Input({
						value: "{userTemplateModel>u_password}"
					})
					
				]
			});
			
			this.readOnlyUserTemplate =  new ColumnListItem({
				cells: [
					new ObjectIdentifier({
						title: "{userTemplateModel>u_id}",
					}), 
					new Text({
						text: "{userTemplateModel>u_name}"
					}), 
					new Text({
						text: "{userTemplateModel>u_email}"
					}), 
					new Text({
						text: "{userTemplateModel>u_role}"
					}), 
					new Text({
						text: "{userTemplateModel>u_password}"
					})
					
				]
			});
		},
		
		
		
		refreshModels : function(){
			var oDataJSON = this.getView().getModel("userJSONModel");
			this.oDataModel.read("/userModel", {
			success : function(odata,res){
			oDataJSON.setProperty("/results",odata.results);
			},
			error: function(){
				console.log("REFRESH FAILED");
			}
			});
		},
		
	
		saveChanges : function(){ // Smart table save
			
			
			this.oDataModel.setHeaders({
				"content-type": "application/json;charset=utf-8"
			});
			var params = {
				success: function(odata,res){
					console.log("Commit Successful",oData,res)
				},
				error:function(err){
					console.log("Commit Failed",err);
				}
			}
			this.oDataModel.submitChanges(params);
			this.refreshModels();
		},
		
		batchDelete : function (oEvent){
			var oTable = this.getView().byId("userSmartTable").getTable();
			var indices = oTable.getSelectedIndices();
			if(indices.length > 0){
				for( var i = 0; i<indices.length; i++){
					var context = oTable.getContextByIndex(indices[i]);
					console.log("Context path",context.sPath);
					this.deleteUserRecord(context.sPath).then( res => console.log("DELETE BATCH",res));
				}
				this.refreshModels();
			}
			else{
				
				MessageToast.show(`No records are selected.`);
			}
		},
		
		
		//Delete single user
		
		deleteUserRecord : async function(sPath) {
		
			if(sPath){
				this.oDataModel.remove(sPath,{
					success : function(odata,res){
						console.log("User deleted:");
						console.log(odata,res);
					},
					error : function(err){
						console.log("User deletion failed:",err);
					}
				});
				
			}
			else{
				console.log("deleteUserRecord:Error - No sPath provided");
			}
		},

		//Add Single User to DB
		
		addUserRecord : function(user){
			if(user){
				this.oDataModel.create("/userModel",user,{
					success: function (odata,result){
						console.log("User Added:",odata.u_email);
						return odata;
					},
					error: function(err){
						return err;
					}
				});
			}
			else{
				console.log("addUserRecord:Error - No user provided")
			} 
		},
		
		//Blank record with Id for Smart Table
		newUserRecord : function(){
			var oTable = this.byId("userSmartTable");
			if(oTable.editable){
				this.addUserRecord({
					u_id:Date.now(),
					u_name:"",
					u_email:"",
					u_role:"",
					u_password:"bcone@123"
				});
			}
			else{
				MessageToast.show("Table is in read mode.");
			}
		},
		
		//Update Single User
		
		updateUserRecord : function(user) {
			if(user){
				var updatePath = "/userModel('"+user.u_id+"')"; 
				this.oDataModel.update(updatePath,user,{
					success: function (odata,res)  {
						console.log("User updated :",odata,res);
					},
					error: function(err){
						console.log("User update failed :",err);
					}
	 			});
	 			this.closeUploadDialog();
			}
			else{
				console.log("updateUserRecord:Error - No user provided")
			}
		},
		
		// Add multiple users to DB VIA upload : Save event
		batchUploadSave : function(){
			var users =	this.getView().getModel("userTemplateModel").getProperty("/users");
			
			if(users.length > 0 ){
				var user_ids = this.getView().getModel("userJSONModel").getProperty("/ids");
				users.forEach(user => {
					var update = false;
					user_ids.map( id => {
						if(user.u_id == id){
							update = true;
						}
					})
					if(update){
						this.updateUserRecord(user);              
					}
					else{
						this.addUserRecord(user); 
					}
				});
				
				this.closeUploadDialog();
			}
			else{
				MessageToast.show("please add record to perform submit");
			}
		
		},
		
		
		// Initiate Dialog
		initiateDialog : function(dialogId,filename){
			var viewPath = "UI5_webapp.webapp.view.";
			var oView = this.getView();
			if(!this.byId(dialogId)){
				Fragment.load({
					id:oView.getId(),
					name:viewPath+filename,
					controller : this
				}).then( function (oDialog) {
					oView.addDependent(oDialog);
					oDialog.open();
				});
			}
			else{
				this.byId(dialogId).open();
			}
			
		},
		
		//close Dialog
		closeDialog : function(dialogId){
			this.byId(dialogId).close();
		},
		

		//Upload event handler
		
		handleUploadEvent : function(){
			this.initiateDialog("uploadDetailsDialog", "UploadDetails");
		},
		
		//Close upload dialog
		
		closeUploadDialog : function (oEvent){
			this.getOwnerComponent().resetUsers();
			this.closeDialog("uploadDetailsDialog");
			if(this.getView().byId("editBtn").visible){
				this.readUpdateTable();
			}
		},
		
		//Rebind upload table on edit/change
		rebindUpdateTable: function(oTemplate, sKeyboardMode) {
			
			this.oUpdateTable.bindItems({
				path: "userTemplateModel>/users",
				template: oTemplate,
				templateShareable: true,
				key: "u_id"
			}).setKeyboardMode(sKeyboardMode);
		},
		
		editUpdateTable : function () {
			if(!this.oUpdateTable){
				this.oUpdateTable = this.getView().byId("userUpdateTable");
			}
			this.getView().byId("editBtn").setVisible(false);
			this.getView().byId("saveBtn").setVisible(true);
			this.getView().byId("addRowBtn").setVisible(true);
			this.getView().byId("clearTable").setVisible(true);
			this.rebindUpdateTable(this.editableUserTemplate, "Edit");
		},
		
		readUpdateTable : function () {
			this.getView().byId("editBtn").setVisible(true);
			this.getView().byId("saveBtn").setVisible(false);
			this.getView().byId("addRowBtn").setVisible(false);
			this.getView().byId("clearTable").setVisible(false);
			this.rebindUpdateTable(this.readOnlyUserTemplate, "Navigation");
		},
		
		updateTableAddRow : function () {
			this.getOwnerComponent().addBlankUser();
		},
		
		handleUploadPress : function(){
			
			var oFileUploader = this.getView().byId("fileUploader");
			if(!oFileUploader.getValue()){
				console.log("select a file!");
				return;
			}
			else{
				
				var oFileUploader = this.getView().byId("fileUploader");
				var onLoaded = new Promise( function(resolve,reject){
					var file = oFileUploader.getFocusDomRef().files[0];
					if( file && window.FileReader){
						var reader = new FileReader();
						reader.onload = function (e){
							var strCSV = e.target.result;
							resolve(strCSV);
						}
					reader.readAsBinaryString(file);
					}
					else{
						reject("No file found!")
					}
				} )
				onLoaded.then(strCSV => {
					const result = this.csvStrToJSON(strCSV);
					if( result.error ){
						MessageToast.show(result.error);        
					}
					else{
						result.data.forEach( user => this.getOwnerComponent().addBlankUser(user) );
						oFileUploader.clear();
					}
				}).catch(err => {
					console.log("Upload Error:",err);
				});
			}
		},
		
		csvStrToJSON : function (strCSV) {
			var parsedStr = Papa.parse(strCSV);
			var headerRow = parsedStr.data.splice(0,1);
			headerRow = [...headerRow[0]];
			var rows = parsedStr.data;
			var result;
			if( !headerRow || !rows ){
				return result = { error:"bad file!" }
			}
			else if( rows.length <= 0 ){
				return result = { error:"No records to upload" }
			}
			
			var data = [];
			
			while( rows.length > 0 ){
				var obj = {};
				var row = rows.splice(0,1);
				row = [...row[0]];
		
				for(var i=0; i<headerRow.length; i++){
					obj[headerRow[i]] = row[i];
				}	
				data.push(obj);
			}
		
			return result = {data};
		},
		
		handleFileTypeMismatch : function(oEvent){
			this.byId("fileUploader").clear();
			MessageToast.show("Only CSV files allowed");
		}
	

	});
});