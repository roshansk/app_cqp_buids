var express = require("express");
var path = require("path");
var port = process.env.PORT || 5000
var app = express();

app.use(express.static(path.join(__dirname,"resources/webapp")));

app.get("/", function(){
    global.console.log("server`s up");
});

app.listen(port);