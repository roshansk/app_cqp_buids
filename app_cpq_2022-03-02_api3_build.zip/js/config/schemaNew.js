const Joi = require('joi');
let schema = {};

schema.QT__SAQDLT = Joi.array().items(Joi.object({
    "Id": Joi.number().allow(null).empty('').default(null),
    "ownerId": Joi.number().allow(null).empty('').default(null),
    "cartId": Joi.number().allow(null).empty('').default(null),
    "Member_ID": Joi.string().allow(null).empty('').default(null),
    "Member_Name": Joi.string().allow(null).empty('').default(null),
    "Member_Type": Joi.string().allow(null).empty('').default(null),
    "Member_Role": Joi.string().allow(null).empty('').default(null),
    "Email": Joi.string().allow(null).empty('').default(null),
    "Phone": Joi.string().allow(null).empty('').default(null),
    "Account_Group_ID": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYADDEDBY": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYDATEADDED": Joi.string().allow(null).empty('').default(null),
    "CpqTableEntryDateModified": Joi.string().allow(null).empty('').default(null),
    "CpqTableEntryModifiedBy": Joi.string().allow(null).empty('').default(null),
    "SAP_CRM_Function": Joi.string().allow(null).empty('').default(null),
    "CPQ_Function": Joi.string().allow(null).empty('').default(null),
    "SAP_CPQ_User_ID": Joi.string().allow(null).empty('').default(null),
    "SAP_CRM_Business_Partner_ID": Joi.string().allow(null).empty('').default(null),
    "SAP_CRM_Function_ID": Joi.string().allow(null).empty('').default(null),
    "ECC_Personnel_ID": Joi.string().allow(null).empty('').default(null),
    "SFDC_User_ID": Joi.string().allow(null).empty('').default(null),
    "CART_ID": Joi.string().allow(null).empty('').default(null),
    "CART_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CART_REV_ID": Joi.string().allow(null).empty('').default(null),
    "CART_REV_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CRM_PARTNERFUNCTION_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_DESC": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_ID": Joi.string().allow(null).empty('').default(null),
    "MEMBER_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "ROLE": Joi.string().allow(null).empty('').default(null),
    "SALESTERRITORY_ID": Joi.string().allow(null).empty('').default(null),
    "SALESTERRITORY_NAME": Joi.string().allow(null).empty('').default(null),
    "SALESTERRITORY_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "SFDC_PARTNERFUNCTION_ID": Joi.string().allow(null).empty('').default(null)
}));

schema.QT__SAQAPH = Joi.array().items(Joi.object({
    "Id": Joi.number().allow(null).empty('').default(null),
    "ownerId": Joi.number().allow(null).empty('').default(null),
    "cartId": Joi.number().allow(null).empty('').default(null),
    "Rule": Joi.string().allow(null).empty('').default(null),
    "Description": Joi.string().allow(null).empty('').default(null),
    "Action": Joi.string().allow(null).empty('').default(null),
    "Approver": Joi.string().allow(null).empty('').default(null),
    "Comment": Joi.string().allow(null).empty('').default(null),
    "AppID": Joi.string().allow(null).empty('').default(null),
    "Performer": Joi.string().allow(null).empty('').default(null),
    "Action Date": Joi.string().allow(null).empty('').default(null),
    "QuoteNumber": Joi.number().allow(null).empty('').default(null),
    "RevisionNumber": Joi.number().allow(null).empty('').default(null)
}));

schema.QT__SAQAPP = Joi.array().items(Joi.object({
    "cartId": Joi.number().allow(null).empty('').default(null),
    "Id": Joi.number().allow(null).empty('').default(null),
    "ownerId": Joi.number().allow(null).empty('').default(null),
    "RULE__c": Joi.string().allow(null).empty('').default(null),
    "APPROVAL_RULE__c": Joi.string().allow(null).empty('').default(null),
    "APPROVAL_REF_ID__c": Joi.string().allow(null).empty('').default(null),
    "COMPITITOR__c": Joi.string().allow(null).empty('').default(null),
    "CURRENT_APPROVER__c": Joi.string().allow(null).empty('').default(null),
    "DESCRIPTION__c": Joi.string().allow(null).empty('').default(null),
    "JUSTIFICATION_COMMENTS__c": Joi.string().allow(null).empty('').default(null),
    "LEVEL__c": Joi.number().allow(null).empty('').default(null),
    "REGION__c": Joi.string().allow(null).empty('').default(null),
    "SUBMITTED_APPROVER__c": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYADDEDBY :": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYDATEADDED :": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYDATEMODIFIED :": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYMODIFIEDBY": Joi.string().allow(null).empty('').default(null),
}));

schema.QT__SAQICT = Joi.array().items(Joi.object({
    "Id": Joi.number().allow(null).empty('').default(null),
    "ownerId": Joi.number().allow(null).empty('').default(null),
    "cartId": Joi.number().allow(null).empty('').default(null),
    "CPQTABLEENTRYADDEDBY": Joi.string().allow(null).empty('').default(null),
    "ADDUSR_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYDATEADDED": Joi.string().allow(null).empty('').default(null),
    "CART_ID": Joi.string().allow(null).empty('').default(null),
    "CART_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CART_REV_ID": Joi.string().allow(null).empty('').default(null),
    "CART_REV_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CITY": Joi.string().allow(null).empty('').default(null),
    "CONTACT_ID": Joi.string().allow(null).empty('').default(null),
    "CONTACT_NAME": Joi.string().allow(null).empty('').default(null),
    "CONTACT_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "COUNTRY": Joi.string().allow(null).empty('').default(null),
    "COUNTRY_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "CRM_PARTNERFUNCTION": Joi.string().allow(null).empty('').default(null),
    "EMAIL": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYMODIFIEDBY": Joi.string().allow(null).empty('').default(null),
    "CPQTABLEENTRYDATEMODIFIED": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_DESCRIPTION": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNERFUNCTION_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNERTYPE_DESCRIPTION": Joi.string().allow(null).empty('').default(null),
    "PARTNERTYPE_ID": Joi.string().allow(null).empty('').default(null),
    "PHONE": Joi.string().allow(null).empty('').default(null),
    "POSTAL_CODE": Joi.string().allow(null).empty('').default(null),
    "PRIMARY": Joi.boolean().allow(null).empty('').default(null),
    "SFDC_CONTACT_ROLE": Joi.string().allow(null).empty('').default(null),
    "SFDC_PARTNERFUNCTION": Joi.string().allow(null).empty('').default(null),
    "STATE": Joi.string().allow(null).empty('').default(null),
    "STATE_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "STREET": Joi.string().allow(null).empty('').default(null),
    "ACTCON_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNER_ID": Joi.string().allow(null).empty('').default(null),
    "PARTNER_NAME": Joi.string().allow(null).empty('').default(null),
    "QTEIVLPTY_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "TYPE": Joi.string().allow(null).empty('').default(null),
    "DISTRICT": Joi.string().allow(null).empty('').default(null),
    "ACCOUNT_RECORD_ID": Joi.string().allow(null).empty('').default(null),
    "ACCOUNT_ID": Joi.string().allow(null).empty('').default(null),
    "ACCOUNT_NAME": Joi.string().allow(null).empty('').default(null),
    "MANUAL_ADDED": Joi.boolean().allow(null).empty('').default(null),
    "FAX_NUMBER": Joi.number().allow(null).empty('').default(null),
    "FAX_NUMBER_EXTENSION": Joi.string().allow(null).empty('').default(null),
    "STANDARD_METHOD": Joi.string().allow(null).empty('').default(null),
    "DATA_LINE": Joi.string().allow(null).empty('').default(null),
    "TELEBOX": Joi.string().allow(null).empty('').default(null),
    "LANGUAGE_ID": Joi.string().allow(null).empty('').default(null),
    "LANGUAGE_NAME": Joi.string().allow(null).empty('').default(null),
    "COMMENTS": Joi.string().allow(null).empty('').default(null),
    "SFDC_FUNCTION": Joi.string().allow(null).empty('').default(null),
    "ERP_CONTACT_NO": Joi.string().allow(null).empty('').default(null)
}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

schema.QT__SAQDLT = Joi.array().items(Joi.object({


}));

module.exports = schema;