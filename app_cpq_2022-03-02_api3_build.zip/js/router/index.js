"use strict";

module.exports = function (app, server) {
	app.use("/test", require("./routes/api.route.js")());
	app.use("/api", require("./routes/api.route.js")());
	
};