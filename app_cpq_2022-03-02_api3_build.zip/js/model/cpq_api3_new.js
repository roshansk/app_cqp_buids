const moment = require('moment');
const executeService = require("../srv/execute");
const executeExternalService = require("../srv/external_api");
const schema = require("../config/schema_api3");
const mailUtils = require("../utils/mail");
const appConfig = require("../config/app");
let timeOfError,
	batchSize = 100,
	tableName,
	today =  moment().format('YYYY-MM-DD HH:MM:DD');
const cpq = {};
const userName = 'manohar.singh@non.agilent.com',
	password = 'Sairam$@12345',
	domain = 'AGILENTTECHNOLOGIESINC_TST';

/*

https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "0","batchSize": "1000","action": "","tableName": "Products"}

*/
cpq.load_masterdata = async (req) => {
	console.log("load_masterdata called")
	return new Promise( async (resolve, reject) => {
		
		try {
			
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
							`Dear User,<br/> <br/>  API3 Started at  - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);
			
			const masterdata_tables = [/*"DIRECTORY_DEFN","ORDER_STATUS_DEFN", "SASOTL",*/"MALGMA"/*,"PRODUCTS"*/]; // Excluded PRODUCTS FOR NOW ALready 945k records filled, SASOTL RETURN Records with PKey NULL

			let result = {
				DIRECTORY_DEFN: { startRow:0, nRows:[] },
				MALGMA: { startRow:0, nRows:[] },
				MAMSOP: { startRow:0, nRows:[] },
				ORDER_STATUS_DEFN: { startRow:0, nRows:[] },
				PRODUCTS: { startRow:0, nRows:[] },
				SASOTL: { startRow:0, nRows:[] }
			};
			
			
			let url, queryToHANA = [],endRow=0, res_insert_hana,getCallCount=0;
				result = { ...result }; //Clearing result object
			Promise.all(masterdata_tables.map( async (table) => { //looping for table names
					tableName = table;
					let api_res;
					do{
						result[table] = { startRow:result[table].startRow, nRows:[] };
						
						do{//Loop till Required No records - 1000 in array
							url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "${result[table].startRow}","batchSize": "${batchSize}","action": "","tableName": "${table}"}`;
							
							try {
								//console.log("Before API3 GET CALL!");
								api_res = await executeExternalService.callApi({ //API call for table
								url,
								methodType: 'GET'
								});
							}catch(error){
								
								console.log("API3 call error:",error);
								mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
								`Dear User,<br/> <br/> Transfer failed for API3 GET CALL at startRow : ${result[table].startRow}  fpr Table - ${table}  ${today}<br/>  Time of Error - ${ new Date() } <br/> Error - ${error}<br/><br/><br/>Regards.`
								);
								return reject(error);
							}
							
							
							getCallCount += 1;
							
							//console.log(` API3 GET CALL FOR ${table}, LINE NUMBER 53`,getCallCount);
							
							if(api_res.Data && api_res.Data.length >= 100){
								result[table].nRows = [...result[table].nRows,...api_res.Data];
								result[table].startRow += 100;
							}
							else if(api_res.Data && api_res.Data.length < 100){
								result[table].nRows = [...result[table].nRows,...api_res.Data];
								result[table].startRow +=  api_res.Data.length;
								endRow = result[table].startRow ;
								console.log(`End Row Reached for Table ${table}, Total Row Count : ${endRow}`);
							}
							else{
								let err = api_res;
								console.log("API3 CALL ERROR",err);
								mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
								`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${result[table].startRow}  fpr Table - ${table}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
								);
								return reject(err);
								
							}
							
							
						
						}while( api_res.Data.length >= 100 &&  result[table].nRows.length < 3000 );
						
						
					
						try{
							//console.log("TRY BLOCK: Insert Into HANA, Line Number: 68");
							await cpq.insertIntoHANA(table,result[table].startRow,result[table].nRows);
						}catch(err){
							console.log("error from INSERT HANA FUNCTION CALL",err);
							mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
							`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${result[table].startRow}  fpr Table - ${table}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
							);
							return reject(err);
						}
						console.log(`Records Passed to HANA For table ${table} : ${result[table].startRow}`);
						//console.log("While", api_res.Data == undefined , api_res.Data.length > 0);
					}while( api_res.Data && api_res.Data.length >= 100);
						

				})).then( values => {
					console.log("End Reached!");
						mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
							`Dear User,<br/> <br/>  API3 - Data inserted successfully  - ${ new Date() } <br/><br/><br/><br/>Regards.`
						);	
					return resolve ({
						code:200,
						mMsg:"Data inserted successfully"
					});
				}).catch(error => {
					console.log(error);
					mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
							`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${result[tableName].startRow} fpr Table - ${tableName}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
					);
					return reject(error);
				})
			

		} catch (error) {
			console.log("Error",error);
			console.log(error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${result[tableName].startRow}  fpr Table - ${tableName}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);
			return reject(error);
		}

	});

}

cpq.insertIntoHANA = function (table,startRow,data) {
	
	console.log("WIP");
	return new Promise ( async(resolve,reject) => {
	
		const procedureNames = { 
			"DIRECTORY_DEFN" : "sp_write_data_tmp_t_ib_cpq_directory_defn",
			"MALGMA" : "sp_write_data_tmp_t_ib_cpq_malgma",
			"MAMSOP" : "sp_write_data_tmp_t_ib_cpq_mamsop",
			"ORDER_STATUS_DEFN" : "sp_write_data_tmp_t_ib_cpq_order_status_defn",
			"PRODUCTS" : "sp_write_data_tmp_t_ib_cpq_products",
			"SASOTL" : "sp_write_data_tmp_t_ib_cpq_sasotl"
			
		}
		
		const { error,value } = schema[table].validate(data, {
					stripUnknown: true
				});
		
		if (error) {
			console.log(error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${startRow}  fpr Table - ${table}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);
			return reject(error);
		} 
		else{
			value.map(data => {
				let keys = Object.keys(data);
				keys.map(key => {
					data[key] = data[key] && data[key] != '' ? data[key] : null;
				})
			});
			
			var spBody = {
				schema: '',
				procedureName: procedureNames[table],
				query: {
					INPUT_ARRAY: value
				}
			};

			return resolve(executeService.executeProcedure(spBody)); 
		}
		
	}); 
}



module.exports = cpq;