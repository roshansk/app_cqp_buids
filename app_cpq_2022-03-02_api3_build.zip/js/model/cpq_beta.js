const moment = require('moment');
const executeService = require("../srv/execute");
const executeExternalService = require("../srv/external_api");
const schema = require("../config/schema_api3");
const mailUtils = require("../utils/mail");
const appConfig = require("../config/app");
let timeOfError,
	batchSize = 100, //Change Batch Size for API call
	pocBatchSize = 1000, // Change Batch Size for Poc call
	reRun = false,
	tableName,
	today =  moment().format('YYYY-MM-DD HH:MM:DD');
const cpq = {};
const userName = 'manohar.singh@non.agilent.com',
	password = 'Sairam$@12345',
	domain = 'AGILENTTECHNOLOGIESINC_TST';
	
let resultTemplate = {
				DIRECTORY_DEFN: [] ,
				MALGMA: [] ,
				MAMSOP: [] ,
				ORDER_STATUS_DEFN: [] ,
				PRODUCTS: [] ,
				SASOTL: [] 
};

let masterdata_tables = [
		/*{
			table:"DIRECTORY_DEFN",
			startRow:0
		},
		{
			table:"ORDER_STATUS_DEFN", 
			startRow:0
		},
		{
			table:"SASOTL",
			startRow:0
		},*/
		{
			table:"MALGMA",
			startRow:0
		}
	];


/*

https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "0","batchSize": "1000","action": "","tableName": "Products"}

*/
cpq.load_masterdata = async (req) => {
	
	if(!reRun){ //if reRun = false, !reRun = true
		batchSize = req.query.batchSize ? req.query.batchSize : batchSize; //Take variables from request if provided
		pocBatchSize = req.query.pocBatchSize ? req.query.pocBatchSize : pocBatchSize;
		masterdata_tables = req.query.config ? JSON.parse(req.query.config) : masterdata_tables;
		console.log(`CONFIG batchSize : ${batchSize}, POC batchSize :${pocBatchSize}, table config : ${JSON.stringify(masterdata_tables)}`);
		console.log("load_masterdata called")
		
	}

	
	return new Promise( async (resolve, reject) => {
		
		try {
			
			if(!reRun){  //if reRun = false, !reRun = true
				mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
							`Dear User,<br/> <br/>  API3 Started at  - ${ new Date() } <br/><br/><br/><br/>Regards.`
				);
			}else{
				reRun = !reRun;
			}
			
			do{
				let result = { ...resultTemplate  };
				result = await cpq.fetchData( masterdata_tables, result ).catch( error => {
					console.log("Execution Failed, ReRun Started");
					mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
						`Dear User,<br/> <br/>  Execution Failed, ReRun Started at point${JSON.stringify(masterdata_tables)} - ${ new Date() } <br/><br/><br/><br/>Regards.`
					);	
					return reject ({
						mMsg:"Execution Failed, ReRun Started"
					});
				});
				
				if(!reRun){
					try{
					//console.log("Try insert into hana",masterdata_tables);
					await cpq.insertIntoHANA( result, masterdata_tables ); //Insert TO HANA Call
					}catch (error) {
						console.log("Error at load_masterdata:",error);
						mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
								`Dear User,<br/> <br/> Transfer failed for API3 at point : ${JSON.stringify(masterdata_tables)} at ${today}<br/>  Time of Error - ${ new Date() } <br/>Error:${error}<br/><br/><br/>Regards.`
						);
						return reject(error);
					}
				}
				
			}while(masterdata_tables.length > 0);
			
			if(!reRun){
				
				console.log("End Reached!");
				mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
					`Dear User,<br/> <br/>  API3 - Data inserted successfully  - ${ new Date() } <br/><br/><br/><br/>Regards.`
				);	
				return resolve ({
					code:200,
					mMsg:"Data inserted successfully"
				});
				
			}
			

		} catch (error) {
			console.log("Error at load_masterdata:",error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at point : ${JSON.stringify(masterdata_tables)} at ${today}<br/>  Time of Error - ${ new Date() } <br/>Error:${error}<br/><br/><br/>Regards.`
			);
			return reject(error);
		}

	});

}

cpq.fetchData = async function ( tablesObj, result ) {
	let breakpoint = tablesObj;
	return new Promise( async (resolve,reject) => {
	let endRow,lastRow;
			
	Promise.all( 
		
		masterdata_tables.map( async obj => {
			let api_res;
			endRow = 0;
			do{
				url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "${obj.startRow}","batchSize": "${batchSize}","action": "","tableName": "${obj.table}"}`;
				api_res = await executeExternalService.callApi({ url, methodType: 'GET'}).catch( error => {
					console.log(`API CALL CATCH : Execution broke for table: ${obj.table}  at startRow: ${obj.startRow} error - ${error}`);
					reRun = true;
					masterdata_tables = breakpoint;
					cpq.load_masterdata();
					return reject(error);
				});
				
				
				
				if( api_res.Data && api_res.Data.length < batchSize ){ //Change Batch size 
					obj.startRow += api_res.Data.length;
					endRow += obj.startRow + api_res.Data.length;
					//masterdata_tables = masterdata_tables.filter( done => done.table != obj.table );
					console.log( `End row reached for table ${obj.table}, total records - ${endRow}` );
					//return true;
				}
				
				result[obj.table] = [ ...result[obj.table], ...api_res.Data];
				obj.startRow += api_res.Data.length;
				//let batchLength = result[obj.table].length;
				//lastRow = result[obj.table][batchLength-1];
				//console.log("Last Row:",lastRow);
			}while( api_res.Data.length >= batchSize && result[obj.table].length < pocBatchSize  )
			
		})
		
	).then( values => {
	return  resolve(result);
	}).catch(error => { return reject(error) });
	
	} );
	
}

cpq.insertIntoHANA = function (result,tables) {
	return new Promise ( async(resolve,reject) => {
	console.log("insert into hana call, rows inserted",masterdata_tables);
		const procedureNames = { 
			"DIRECTORY_DEFN" : "sp_write_data_tmp_t_ib_cpq_directory_defn",
			"MALGMA" : "sp_write_data_tmp_t_ib_cpq_malgma",
			"MAMSOP" : "sp_write_data_tmp_t_ib_cpq_mamsop",
			"ORDER_STATUS_DEFN" : "sp_write_data_tmp_t_ib_cpq_order_status_defn",
			"PRODUCTS" : "sp_write_data_tmp_t_ib_cpq_products",
			"SASOTL" : "sp_write_data_tmp_t_ib_cpq_sasotl"
			
		}
		let request_to_hana = [];
		
		
		tables.map( async obj => {
			let table = obj.table;
			let data = result[table];
			let startRow  = obj.startRow;
			
		const { error,value } = schema[table].validate(data, {
					stripUnknown: true
		});
		
		if (error) {
			console.log(error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at point : ${JSON.stringify(masterdata_tables)} at ${today}<br/>  Time of Error - ${ new Date() } <br/>Error:${error}<br/><br/><br/>Regards.`
			);
			return reject(error);
		} 
		else{
			value.map(data => {
				let keys = Object.keys(data);
				keys.map(key => {
					data[key] = data[key] && data[key] != '' ? data[key] : null;
				})
			});
			
			var spBody = {
				schema: '',
				procedureName: procedureNames[table],
				query: {
					INPUT_ARRAY: value
				}
			};

			request_to_hana.push(executeService.executeProcedure(spBody)); 
		}
			
			
		});
		
		Promise.all(request_to_hana).then(values => {
			masterdata_tables = masterdata_tables.filter( tableObj => result[tableObj.table].length >= pocBatchSize );//Change Batch Size
			resolve(true);
		}).catch(error => { return reject(error) } );
	
	}); 
}



module.exports = cpq;