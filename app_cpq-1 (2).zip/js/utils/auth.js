const {
	promisify
} = require('util');
const {
	createConnection
} = require("@sap/hdbext");
const createConnectionProm = promisify(createConnection);
const xsenv = require("@sap/xsenv");
const services = xsenv.getServices({
	hanaConfig: {
		tag: "hana"
	}
});

let auth = {
	deployedAppName: "app_xsa_jobs",
	debugScopes: [
		"APP_XSA_JOBS.admin",
	],
	runningAppName: function (req) {
		return JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials.xsappname.split("!")[0];
	},
	isDebug: function (req) {
		try {
			return auth.runningAppName(req).toLowerCase() !== auth.deployedAppName.toLowerCase();
		} catch (e) {
			return false;
		}
	},
	hasScope: function (req, scope) {
		if (auth.isDebug(req)) {
			let scopes = auth.debugScopes.map(function (i) {
				if (i.indexOf(".")) {
					return i.split(".")[1];
				} else {
					return i;
				}
			});

			if (scopes.indexOf(scope) != -1) {
				return true;
			}

			return false;
		} else {
			return req.authInfo.checkLocalScope(scope);
		}
	},
	currentUser: async function (req) {
		let client = await createConnectionProm(services.hanaConfig);
		let prepareProm = await promisify(client.prepare).bind(client);
		let statement = await prepareProm(`SELECT * FROM "vw_employee" WHERE UPPER("NT_ACCOUNT")=UPPER('${req.authInfo.getLogonName()}') `);
		let execProm = await promisify(statement.exec).bind(statement);
		let result = await execProm();

		var user = {
			appName: auth.runningAppName(req),
			username: req.authInfo.getLogonName(),
			displayName: result[0].FULLNAME,
			scopes: []
		};

		if (auth.isDebug(req)) {
			user.scopes = auth.debugScopes;
		} else {
			user.scopes = req.authInfo.getTokenInfo().getPayload().scope;
		}

		return user;
	}
};

module.exports = auth;