const moment = require('moment');
const executeService = require("../srv/execute");
const executeExternalService = require("../srv/external_api");
const schema = require("../config/schema");
const mailUtils = require("../utils/mail");
const appConfig = require("../config/app");
let timeOfError,startTime,today;
const cpq = {};
const userName = 'manohar.singh@non.agilent.com',
	password = 'Sairam$@12345',
	domain = 'AGILENTTECHNOLOGIESINC_TST';
cpq.getQuotesAndUpdateHana = async({
	query,
	authInfo
}) => {
	return new Promise(async(resolve, reject) => {
		try {
			startTime = query.fromDate ? query.fromDate : '2019-11-1 15:49:53.840';
			timeOfError = startTime;
			today = query.toDate ? query.toDate : moment().format('YYYY-MM-DD HH:MM:DD');
			let url;
			let res;
			let firstAPIFinalResult = [];
			let secondFinalAPIDataTemp = {
				Cart: [],
				Cart_Revisions: [],
				Cart2: [],
				Cart_Item: [],
				CartItemCustomFields: [],
				current_cart_responsibility: [],
				scparams: [],
				QT__SAQAPH: [],
				QT__SAQAPP: [],
				QT__SAQDLT: [],
				QT__SAQICT: [],
				QT__SAQPCD: [],
				QT__SAQTDV: [],
				QT__SAQTFA: [],
				QT__SAQTIP: []
			}
			let secondFinalAPIData = {...secondFinalAPIDataTemp
			};
			console.log("Start Time=>", new Date())
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Start Time: Hana CPQ API call started',
				`Dear User,<br/>Data filter ${startTime}  -  ${today}<br/> ${new Date()}<br/><br/><br/><br/>Regards.`
			);
			do {
				let reRunAPI1;
				url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptname=GetQuotesModifiedAPI&username=${userName}&password=${password}&domain=${domain}&Param={'FromDateTime': '${startTime}','ToDateTime': '${today}'}`;
				
				do{
					reRunAPI1 = false;
					res = await executeExternalService.callApi({ url, methodType: 'GET'}).catch( err => {
						console.log("API1 GET call failed, rerun for this batch");
						reRunAPI1 = true;
					});
					
				}while(reRunAPI1);
				
				if (res.NumberOfQuotes) {
					firstAPIFinalResult = [...firstAPIFinalResult, ...res.Quotes];
					try {
						secondFinalAPIData = await cpq.fetchSecondAPIData({
							quotes: res.Quotes,
							result: secondFinalAPIData
						});

						console.log("firstAPIFinalResult.length", firstAPIFinalResult.length)
						if (firstAPIFinalResult.length >= 1000) {
							console.log("m inside if condition")
							await cpq.insertFirstAPIDataToHana({
								Quotes: firstAPIFinalResult
							});
							firstAPIFinalResult = [];
							await cpq.insertSecondAPIDataToHana(secondFinalAPIData);
							secondFinalAPIData = {...secondFinalAPIDataTemp
							};
						}
						
						startTime = res.NextPageDateTime;
						timeOfError = res.NextPageDateTime;
						
					} catch (err) {
						console.log("Error: ", err)
						console.log("Error at startTime1", timeOfError);
						cpq.logError({
							date: timeOfError,
							message: JSON.stringify(err)
						})
						mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 01',
							`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 1 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${err}</h3><br/><br/>Regards.`
						);
						return reject(err)
					}
				} else {
					console.log("End Loop Reached!",firstAPIFinalResult.length);
					startTime = null;
					timeOfError = null;
					try {
						await cpq.insertFirstAPIDataToHana({
						Quotes: firstAPIFinalResult
						});
						firstAPIFinalResult = [];
						await cpq.insertSecondAPIDataToHana(secondFinalAPIData);
						secondFinalAPIData = {...secondFinalAPIDataTemp};
						console.log("Looping End here");
					} catch (err) {
						console.log("Error at startTime2", timeOfError);
						cpq.logError({
							date: timeOfError,
							message: JSON.stringify(err)
						})
						mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 02',
							`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 2 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${err}</h3><br/><br/>Regards.`
						);
						return reject(err)
					}
				}
			} while (res && res.NumberOfQuotes && startTime)

			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'End Time: Successfully executed !!',
				`Dear User,<br/><br/>Data filter ${startTime}  -  ${today}<br/> ${new Date()}<br/><br/><br/><br/>Regards.`
			);
			console.log("End Time=>", new Date());
			return resolve({
				code: 200,
				message: 'Data Uploaded Successfully'
			});
		} catch (err) {
			console.log("Error at startTime3", timeOfError)
			cpq.logError({
				date: timeOfError,
				message: JSON.stringify(err)
			})
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 03',
				`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 3 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${err}</h3><br/><br/>Regards.`
			);
			console.log("Add Get Quotes API error", err)
			return reject(JSON.stringify(err));
		}
	});
};

cpq.fetchSecondAPIData = ({
	quotes,
	result
}) => {
	return new Promise(async(resolve, reject) => {
		let userId,
			cartId,
			quoteNumber,
			reRun = false;
		let apiArray = [];
		let url;
		for( let i = 0; i<quotes.length; i++ ){
			obj = quotes[i];
			userId = obj.UserId;
			cartId = obj.CartId;
			quoteNumber = obj.CompositeQuoteNumber;
			url =
				`https://sandbox.webcomcpq.com/customapi/executescript?scriptname=GetQuoteTablesAPI&username=${userName}&password=${password}&domain=${domain}&Param={'UserId':${userId},'CartId':${cartId},'QuoteNumber': '${quoteNumber}'}`;
			apiArray.push(executeExternalService.callApi({
				url,
				methodType: 'GET'
			}).catch( error => {
				reRun  = true;
				console.log(`API2 call failed at QuoteNumber : ${quoteNumber}, Rerun started for this batch`);
			}));
			
			if(reRun){
				apiArray.slice(-1);
				i -= 1;
				reRun = false;
			}
		}

		Promise.all(apiArray).then((values) => {
			values.map(res => {
				if (res) {
					if (res && res.StandardTables.length) {
						
						res.StandardTables.map(obj => {
							if(result[obj.StandardTableName]){
							result[obj.StandardTableName] = [...result[obj.StandardTableName],...obj.Rows];
							
							}
						});
					}
					if (res && res.QuoteTables.length) {
						res.QuoteTables.map(obj => {
							if(result[obj.QuoteTableName]){
							result[obj.QuoteTableName] = [...result[obj.QuoteTableName],...obj.Rows];
							
							}
						});
						
					}
				}
				return resolve(result);
			})
		}).catch(error => {
			console.log("Error at startTime4", timeOfError)
			cpq.logError({
				date: timeOfError,
				message: JSON.stringify(error)
			})
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 04',
				`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 4 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${error}</h3><br/><br/>Regards.`
			);
			return reject(error)
		});

	});
};

cpq.insertSecondAPIDataToHana = (request) => {
	return new Promise(async(resolve, reject) => {
		let procedureMapping = {
		
			"Cart": "sp_write_data_tmp_t_ib_cpq_cart",
			"Cart2": "sp_write_data_tmp_t_ib_cpq_cart_ext",
			"Cart_Revisions": "sp_write_data_tmp_t_ib_cpq_cartrevisions",
			"Cart_Item": "sp_write_data_tmp_t_ib_cpq_cart_item",
			"CartItemCustomFields": "sp_write_data_tmp_t_ib_cpq_cartitemcustomfields",
			"current_cart_responsibility": "sp_write_data_tmp_t_ib_cpq_current_cart_responsibility",
			"scparams": "sp_write_data_tmp_t_ib_cpq_quote_attributes",
			"QT__SAQAPH": "sp_write_data_tmp_t_ib_cpq_saqaph",
			"QT__SAQAPP": "sp_write_data_tmp_t_ib_cpq_saqapp",
			"QT__SAQDLT": "sp_write_data_tmp_t_ib_cpq_saqdlt",
			"QT__SAQICT": "sp_write_data_tmp_t_ib_cpq_saqict",
			"QT__SAQPCD": "sp_write_data_tmp_t_ib_cpq_saqpcd",
			"QT__SAQTDV": "sp_write_data_tmp_t_ib_cpq_saqtdv",
			"QT__SAQTFA": "sp_write_data_tmp_t_ib_cpq_saqtfa",
			"QT__SAQTIP": "sp_write_data_tmp_t_ib_cpq_saqtip"

		};
		let dataObjectKeys = Object.keys(request);
		let queryToHana = [];
		dataObjectKeys.map(obj => {
			if ((   obj == 'Cart' || obj == 'Cart2' || obj == 'Cart_Revisions' || obj == 'Cart_Item' || obj == 'CartItemCustomFields' ||
					obj == 'current_cart_responsibility' || obj == 'scparams' || obj == 'QT__SAQAPH' || obj == 'QT__SAQAPP' || 
					obj == 'QT__SAQDLT' || obj == 'QT__SAQICT' || obj == 'QT__SAQPCD' || obj == 'QT__SAQTDV' || obj == 'QT__SAQTFA' || 
					obj == 'QT__SAQTIP'	) && request[obj].length) {
				
				const {
					error,
					value
				} = schema[obj].validate(request[obj], {
					stripUnknown: true
				});
				if (error) {
					console.log("JOI VALIDATION ERROR:",error);
					return reject(error)
				} else {
					value.map(data => {
						let keys = Object.keys(data);
						keys.map(key => {
							data[key] = data[key] && data[key] != '' ? data[key] : null;
						})
					})
					var spBody = {
						schema: '',
						procedureName: procedureMapping[obj],
						query: {
							INPUT_ARRAY: value
						}
					};
					console.log("CALLING SECOND API");
					queryToHana.push(executeService.executeProcedure(spBody));
				}
			}
		});
		Promise.all(queryToHana).then((values) => {
			return resolve(true);
		}).catch(error => {
			console.log("Error at startTime5", timeOfError);
			cpq.logError({
				date: timeOfError,
				message: JSON.stringify(error)
			})
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 05',
				`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 5 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${err}</h3><br/><br/>Regards.`
			);
			return reject(error)
		});

	});
}
cpq.insertFirstAPIDataToHana = (require) => {
	return new Promise(async(resolve, reject) => {
		let insertFirstAPIObj = [];
		require.Quotes.map(data => {
			insertFirstAPIObj.push({
				USERID: data.UserId,
				CARTID: data.CartId,
				MODIFIEDDATE: data.ModifiedDate,
				COMPOSITEQUOTENUMBER: data.CompositeQuoteNumber,
				REVID: data.RevId
			});
		})
		var spBody = {
			schema: '',
			procedureName: 'sp_write_data_tmp_t_ib_cpq_interim',
			query: {
				INPUT_ARRAY: insertFirstAPIObj
			}
		};
		try {
			await executeService.executeProcedure(spBody);
			console.log("First Query  executed")
			return resolve(true);
		} catch (err) {
			cpq.logError({
				date: timeOfError,
				message: JSON.stringify(err)
			});
			console.log("Error at startTime6", timeOfError);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error in Step 06',
				`Dear User,<br/> <br/>Data filter ${startTime}  -  ${today}<br/>  at 6 ${timeOfError} <br/><h2>ERROR: </h2><br/><h3>${err}</h3><br/><br/>Regards.`
			);
			return reject(err);
		}
	});
}

cpq.logError = async(request) => {
	let query = `insert into "syn_tbl_data_tmp_t_cpq_error_log" values('${request.date}','${request.message}')`
	await executeService.executeQuery(query);
	return true;
}

cpq.upsertEvent = async({
	body
}) => {
	return new Promise(async(resolve, reject) => {
		try {
			url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptname=GetQuoteTablesAPI&username=${userName}&password=${password}&domain=${domain}&Param={'UserId':${body.OwnerId},'CartId':${body.QuoteId},'QuoteNumber': '${body.CompositeNumber}'}`;
			console.log("url", url)
			let res = await executeExternalService.callApi({
				url,
				methodType: 'GET'
			});
			let result = {};
			if (res && res.StandardTables.length) {
				res.StandardTables.map(obj => {
					result[obj.StandardTableName] = obj.Rows;
				});
			}
			if (res && res.QuoteTables.length) {
				res.QuoteTables.map(obj => {
					result[obj.QuoteTableName] = obj.Rows;
				});
			}
			await cpq.insertSecondAPIDataToHana(result);
			return resolve(result);
		} catch (err) {
			return reject(err);
		}
	});
};

cpq.deleteEvent = async({
	body
}) => {
	return new Promise(async(resolve, reject) => {
		try {
			var spBody = {
				schema: '',
				procedureName: 'sp_delete_data_tmp_t_ib_cpq_cart',
				query: {
					CART_ID: body.QuoteId,
					USERID: body.OwnerId
				}
			};
			executeService.executeProcedure(spBody);
			return resolve({message : 'Quote Deleted Successfully'});
		} catch (err) {
			return reject(err);
		}
	});
}

module.exports = cpq;