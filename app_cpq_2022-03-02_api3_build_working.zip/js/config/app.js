let config = {
	uaaConfig: {
		uaaCredentials: JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials
	},
	mailTo : 'nikhil.chandak@non.agilent.com,amit.nage@non.agilent.com,manue.balakrishnan@non.agilent.com'
};

module.exports = config;