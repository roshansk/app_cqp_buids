const express = require('express');
const xsenv = require("@sap/xsenv");
const router = express.Router();
const passport = require("passport");
const cpqModel = require("../../model/cpq");
const cpqAPI3 = require("../../model/cpq_api3");

module.exports = () => {
	var app = express.Router();
	// app.use(passport.authenticate("basic", {
	// 	session: false
	// }));
	app.post("/event_load", async(req, res) => {
		req.setTimeout(0);
		try {
			if (req.body && req.body.EventType) {
				if (req.body.EventType == 'QuoteEvent.OnQuoteDeleted') {
					let result = await cpqModel.deleteEvent(req);
					res.status(204).json(result);
				} else {
					let result = await cpqModel.upsertEvent(req);
					res.status(204).json(result);
				}
			} else {
				res.status(405).json({
					message: 'Incorrect Event Type'
				});
			}
		} catch (err) {
			console.log("m here",err)
			res.status(504).json(err);
		}
	});
	
	app.get("/full_load", async(req, res) => {
		req.setTimeout(0);
		try {
			let result = await cpqModel.getQuotesAndUpdateHana(req);
			res.status(204).json(result);
		} catch (err) {
			res.status(504).json(err);
		}
	});
	
	
	//API3 ENDPOINT CALL
	
	app.get("/load_masterdata", async(req, res) => {
		req.setTimeout(0);
		try {
			let result = await cpqAPI3.load_masterdata(req);
			res.status(204).json(result);
		} catch (err) {
			res.status(504).json(err);
		}
	});
	
	
	return app;
	
};