const moment = require('moment');
const executeService = require("../srv/execute");
const executeExternalService = require("../srv/external_api");
const schema = require("../config/schema_api3");
const mailUtils = require("../utils/mail");
const appConfig = require("../config/app");
let timeOfError;
const cpq = {};
const userName = 'manohar.singh@non.agilent.com',
	password = 'Sairam$@12345',
	domain = 'AGILENTTECHNOLOGIESINC_TST';

/*

https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "0","batchSize": "1000","action": "","tableName": "Products"}

*/
cpq.load_masterdata = async (req) => {
	console.log("load_masterdata called")
	return new Promise( async (resolve, reject) => {
		
		try {
			const masterdata_tables = ["DIRECTORY_DEFN", "MALGMA","MAMSOP", "ORDER_STATUS_DEFN", "PRODUCTS", "SASOTL"];

			result = {
				DIRECTORY_DEFN: [],
				MALGMA: [],
				MAMSOP: [],
				ORDER_STATUS_DEFN: [],
				PRODUCTS: [],
				SASOTL: []
			};
			let url,api_res, queryToHANA = [], res_insert_hana;
				result = { ...result }; //Clearing result object
				masterdata_tables.map( async (table) => { //looping for table names

					url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "0","batchSize": "100","action": "","tableName": "${table}"}`;
			
					api_res = await executeExternalService.callApi({ //API call for table
						url,
						methodType: 'GET'
					});
				
					if( api_res.Data && api_res.Data.length > 0 ){ //rows and number of rows check
						result[table] = api_res.Data;
						console.log("Got data for table:",table)
						try{
							res_insert_hana =	await cpq.insertIntoHANA(table,result[table]);
							queryToHANA.push(res_insert_hana);
						}catch(err){
							console.log("error from INSERT HANA CALL",err);
							return reject(err);
						}
					}
			
				});
				
				Promise.all(queryToHANA).then( values => {
					console.log("QUERYTOAHANA",queryToHANA.length);
					return resolve ({
						code:200,
						mMsg:"Data inserted successfully"
					});
				} ).catch(error => {
					console.log(error);
					return reject(error);
				})
				

		} catch (error) {
			console.log("Error",error);
			return reject(error);
		}

	})

}

cpq.insertIntoHANA = async function (table,data) {
	
	console.log("WIP");
	return new Promise ( async(resolve,reject) => {
	
		const procedureNames = { 
			"DIRECTORY_DEFN" : "sp_write_data_tmp_t_ib_cpq_directory_defn",
			"MALGMA" : "sp_write_data_tmp_t_ib_cpq_malgma",
			"MAMSOP" : "sp_write_data_tmp_t_ib_cpq_mamsop",
			"ORDER_STATUS_DEFN" : "sp_write_data_tmp_t_ib_cpq_order_status_defn",
			"PRODUCTS" : "sp_write_data_tmp_t_ib_cpq_products",
			"SASOTL" : "sp_write_data_tmp_t_ib_cpq_sasotl"
			
		}
		
		const { error,value } = schema[table].validate(data, {
					stripUnknown: true
				});
		
		if (error) {
			return reject(error)
		} 
		else{
			value.map(data => {
				let keys = Object.keys(data);
				keys.map(key => {
					data[key] = data[key] && data[key] != '' ? data[key] : null;
				})
			});
			
			var spBody = {
				schema: '',
				procedureName: procedureNames[table],
				query: {
					INPUT_ARRAY: value
				}
			};

			executeService.executeProcedure(spBody);
			console.log("DATA INSERTED FORTABLE :", table);
		}
		
	}); 
}

module.exports = cpq;