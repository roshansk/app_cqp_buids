/*eslint no-console: 0*/
"use strict";
const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
const apiData = require('./service/data');

app.get("/api/getData", async(req,res) => {
	
	let result = await apiData.getData(req);
	if(result){
		res.status(200).json(result);
	}
	else{
		res.status(504).json({msg:"get data failed"});
	}
});

app.listen(port, function(){
	console.log(`Server started on port ${port}`);
});
