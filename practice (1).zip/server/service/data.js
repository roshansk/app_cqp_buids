const db = require('./db');
const data = {};
let accountNumber,contractNumber;


data.getData = async (req) => {
	
	if(req.query.accountNumber && req.query.contractNumber){
		
		accountNumber = req.query.accountNumber;
		contractNumber = req.query.contractNumber;
		let query = `SELECT DISTINCT "ContractNo", "ContractItem", "ContractType", "ContractStatus", "ContractStartDate", "ContractEndDate", "ContractCreationDate", "CYContractStartDate", "CYContractEndDate", "StdRegion", "StdSubRegion", "GeoUnitDesc", SUM("ContractDailyValueUSD") AS "ContractDailyValueUSD_SUM", SUM("CTDTargetRevenueUSD") AS "CTDTargetRevenueUSD_SUM", SUM("CTDInvoiceRevenueUSD") AS "CTDInvoiceRevenueUSD_SUM", COUNT(*) AS "SoldToCustomer_COUNT" FROM "APP_PPS_CONTRACT_ANALYTICS"."cv_apv_pps_reagent_compliance" WHERE ("SoldToCustomer" = ${accountNumber} AND "ContractNo" = ${contractNumber}) GROUP BY "ContractNo", "ContractItem", "ContractType", "ContractStatus", "ContractStartDate", "ContractEndDate", "ContractCreationDate", "CYContractStartDate", "CYContractEndDate", "StdRegion", "StdSubRegion", "GeoUnitDesc" ORDER BY "ContractNo" ASC, "ContractItem" ASC, "ContractType" ASC, "ContractStatus" ASC, "ContractStartDate" ASC, "ContractEndDate" ASC, "ContractCreationDate" ASC, "CYContractStartDate" ASC, "CYContractEndDate" ASC, "StdRegion" ASC, "StdSubRegion" ASC, "GeoUnitDesc" ASC`;
		
		try{
			let result = await  db.executeQuery(query);
			return result;
		}
		catch(error){
			console.log(`Error - ${error}`);
			return false;
		}
		
	}else{
		console.log("Error - No account Number and contract number provided.");
		return false;
	}

}

module.exports = data;