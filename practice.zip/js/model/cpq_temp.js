const moment = require('moment');
const executeService = require("../srv/execute");
const executeExternalService = require("../srv/external_api");
const schema = require("../config/schema_api3");
const mailUtils = require("../utils/mail");
const appConfig = require("../config/app");
let timeOfError,
	batchSize = 1000,
	tableName,
	today =  moment().format('YYYY-MM-DD HH:MM:DD');
const cpq = {};
const userName = 'manohar.singh@non.agilent.com',
	password = 'Sairam$@12345',
	domain = 'AGILENTTECHNOLOGIESINC_TST';
	
let resultTemplate = {
				DIRECTORY_DEFN: [] ,
				MALGMA: [] ,
				MAMSOP: [] ,
				ORDER_STATUS_DEFN: [] ,
				PRODUCTS: [] ,
				SASOTL: [] 
};

let masterdata_tables = [
		{
			table:"DIRECTORY_DEFN",
			startRow:0
		},
		{
			table:"ORDER_STATUS_DEFN", 
			startRow:0
		},
		{
			table:"SASOTL",
			startRow:0
		},
		{
			table:"MALGMA",
			startRow:0
		}
	];


/*

https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "0","batchSize": "1000","action": "","tableName": "Products"}

*/
cpq.load_masterdata = async (req) => {
	console.log("load_masterdata called")
	return new Promise( async (resolve, reject) => {
		
		try {
			
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
							`Dear User,<br/> <br/>  API3 Started at  - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);
			
			do{
				let result = { ...resultTemplate  };
				result = await cpq.fetchData( masterdata_tables, result );
				try{
					console.log("Try insert into hana",masterdata_tables);
					await cpq.insertIntoHana( result, masterdata_tables );
				}catch (error) {
					console.log("Error at load_masterdata:",error);
					mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
							`Dear User,<br/> <br/> Transfer failed for API3 at point : ${masterdata_tables} at ${today}<br/>  Time of Error - ${ new Date() } <br/>Error:${error}<br/><br/><br/>Regards.`
					);
					return reject(error);
				}
				
			}while(masterdata_tables.length > 0);
			
			console.log("End Reached!");
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'API3 Started',
				`Dear User,<br/> <br/>  API3 - Data inserted successfully  - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);	
			return resolve ({
				code:200,
				mMsg:"Data inserted successfully"
			});
			

		} catch (error) {
			console.log("Error at load_masterdata:",error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at point : ${masterdata_tables} at ${today}<br/>  Time of Error - ${ new Date() } <br/>Error:${error}<br/><br/><br/>Regards.`
			);
			return reject(error);
		}

	});

}

cpq.fetchData = async function ( tablesObj, result ) {
	
	let endRow = 0;
			
	Promise.all( 
		
		masterdata_tables.map( async obj => {
			let api_res;
			
			do{
				
				url = `https://sandbox.webcomcpq.com/customapi/executescript?scriptName=getproductInfo&username=manohar.singh@non.agilent.com&password=Sairam$@12345&domain=AGILENTTECHNOLOGIESINC_TST&Param={"startRow": "${obj.startRow}","batchSize": "${batchSize}","action": "","tableName": "${obj.table}"}`;
				api_res = await executeExternalService.callApi({ url, methodType: 'GET'});
				
				if( api_res.Data && api_res.Data.length < 1000 ){
					endRow += obj.startRow + api_res.Data.length;
					masterdata_tables = masterdata_tables.filter( done => done.table != obj.table );
					console.log( `End row reached for table ${obj.table}, total records - ${endRow}` );
					return true;
				}
				
				result[obj.table] = [ ...result[obj.table], ...api_res.Data];
				startRow += api_res.Data.length;
				
			}while( api_res.Data.length >= 1000 && result[obj.table] < 3000 );
			
		})
		
	).then( values => {
	return result;
	}).catch(error => { return error });
	
	
}

cpq.insertIntoHANA = function (result,tables) {
	
	console.log("WIP",tables);
	return new Promise ( async(resolve,reject) => {
	
		const procedureNames = { 
			"DIRECTORY_DEFN" : "sp_write_data_tmp_t_ib_cpq_directory_defn",
			"MALGMA" : "sp_write_data_tmp_t_ib_cpq_malgma",
			"MAMSOP" : "sp_write_data_tmp_t_ib_cpq_mamsop",
			"ORDER_STATUS_DEFN" : "sp_write_data_tmp_t_ib_cpq_order_status_defn",
			"PRODUCTS" : "sp_write_data_tmp_t_ib_cpq_products",
			"SASOTL" : "sp_write_data_tmp_t_ib_cpq_sasotl"
			
		}
		let request_to_hana = [];
		
		
		tables.map( async obj => {
			let table = obj.table;
			let data = result[table];
			let startRow  = obj.startRow;
			
		const { error,value } = schema[table].validate(data, {
					stripUnknown: true
		});
		
		if (error) {
			console.log(error);
			mailUtils.send('noreply@agilent.com', appConfig.mailTo, 'Error',
					`Dear User,<br/> <br/> Transfer failed for API3 at startRow : ${startRow}  fpr Table - ${table}  ${today}<br/>  Time of Error - ${ new Date() } <br/><br/><br/><br/>Regards.`
			);
			return reject(error);
		} 
		else{
			value.map(data => {
				let keys = Object.keys(data);
				keys.map(key => {
					data[key] = data[key] && data[key] != '' ? data[key] : null;
				})
			});
			
			var spBody = {
				schema: '',
				procedureName: procedureNames[table],
				query: {
					INPUT_ARRAY: value
				}
			};

			request_to_hana.push(executeService.executeProcedure(spBody)); 
		}
			
			
		});
		
		Promise.all(request_to_hana).then(values => {
			resolve(true);
		}).catch(error => { return reject(error) } );
	
	}); 
}



module.exports = cpq;