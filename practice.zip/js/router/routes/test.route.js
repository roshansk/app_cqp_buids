const express = require('express');
const xsenv = require("@sap/xsenv");
const router = express.Router();
const passport = require("passport");
const cpqModel = require("../../model/cpq");

module.exports = () => {
	var app = express.Router();
	app.post("/test", async(req, res) => {
		try {
			console.log("APi Triggered")
			res.status(200).json({message: 'Hello World'});
		} catch (err) {
			res.status(500).json(err);
		}
	});
	
	return app;
};