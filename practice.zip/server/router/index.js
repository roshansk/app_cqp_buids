"use strict";
const api = require('./router/api.route.js');

modules.exports = function (){
	app.use('/api',api);
} 