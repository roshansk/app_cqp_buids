let config = {
	uaaConfig: {
		uaaCredentials: JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials
	},
	mailTo : 'manohar.singh@non.agilent.com,amit.nage@non.agilent.com,manue.balakrishnan@non.agilent.com,roshan.kamble@non.agilent.com',
	mailToSupport : 'manohar.singh@non.agilent.com,,amit.nage@non.agilent.com,manue.balakrishnan@non.agilent.com,roshan.kamble@non.agilent.com'
};

module.exports = config;