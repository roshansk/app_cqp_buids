var xsenv = require("@sap/xsenv");
var services = xsenv.getServices({
	hanaConfig: {
		tag: "hana"
	}
});
module.exports = services;