module.exports = {
	initNode: function () {
		console.log("Initializing Node...");
		var express = require('express');
		const passport = require("passport");
		const http = require("request");
		const bodyParser = require("body-parser");
		const {
			JWTStrategy
		} = require("@sap/xssec");
		const xsenv = require("@sap/xsenv");
		var hdbext = require("@sap/hdbext");
		const jwtDecode = require("jwt-decode");

		var app = express();
		var BasicStrategy = require("passport-http").BasicStrategy;
		passport.use(new BasicStrategy(
			function (username, password, done) {
				var uaaCredentials = JSON.parse(process.env.VCAP_SERVICES).xsuaa[0].credentials;
				let url = `${uaaCredentials.url}/oauth/token`;
				var credentials = {};
				credentials.username = username;
				credentials.password = password;
				credentials.client_id = uaaCredentials.clientid;
				credentials.client_secret = uaaCredentials.clientsecret;
				credentials.grant_type = "password";
				http.post(url, {
					form: credentials
				}, (error, response, body) => {
					if (response && response.statusCode === 200) {
						body = JSON.parse(body);
						let decoded = jwtDecode(body.access_token);
						return done(null, {
							id: decoded.user_name,
							scopes: body.scope
						});
					} else {
						return done(null, false);
					}
				});
			}
		));
		// Set passport strategy (authentication method) as JWT based on the uaa services
		passport.use("JWT", new JWTStrategy(xsenv.getServices({
			uaa: {
				tag: "xsuaa"
			}
		}).uaa));

		app.use(passport.initialize());
		var hanaOptions = xsenv.getServices({
			hana: {
				tag: "hana"
			}
		});
		app.use(bodyParser.json());
		app.use(bodyParser.urlencoded({
			extended: true
		}));
		console.log("Node finished.");
		return app;
	}
};