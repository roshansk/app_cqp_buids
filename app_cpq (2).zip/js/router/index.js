"use strict";

module.exports = function (app, server) {
	app.use("/api", require("./routes/test.route.js")());
	app.use("/api", require("./routes/api.route.js")());
	
};