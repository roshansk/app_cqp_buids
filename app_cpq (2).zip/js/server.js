/*eslint no-console: 0, no-unused-vars: 0*/
"use strict";

const https = require("https");
var server = require("http").createServer();
const xsenv = require("@sap/xsenv");

https.globalAgent.options.ca = xsenv.loadCertificates();
global.__base = __dirname + "/";
var init = require(global.__base + "utils/initialize");

//Initializing the app
var app = init.initNode();

// app routes
var router = require('./router')(app, server);

// Start the Server
var port  = process.env.PORT || 3000;
app.listen(port, () => {
	console.log(`Server running on port: ${port}`);
});